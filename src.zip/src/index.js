import "./styles.css";
import Swiper from 'swiper';
import { Navigation, Pagination } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

document.addEventListener('click', e => {
    const isDropdownButton = e.target.matches("[data-dropdown-button]")
    if (!isDropdownButton && e.target.closest("[data-dropdown]") != null) return

    let curerentDropdown
    if (isDropdownButton) {
        curerentDropdown = e.target.closest("[data-dropdown]")
        curerentDropdown.classList.toggle("active")
    }

    document.querySelectorAll("[data-dropdown].active").forEach(dropdown => {
        if (dropdown === curerentDropdown) return
        dropdown.classList.remove("active")
    })
});

window.addEventListener('DOMContentLoaded', () => {
  const el = document.querySelector('.swiper');
  console.log('swiper element found?', !!el);

  const swiper = new Swiper(el, {
    modules: [Navigation, Pagination],
    loop: true,
    slidesPerView: 1,
    spaceBetween: 20,
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  });
});